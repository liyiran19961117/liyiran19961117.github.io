﻿document.writeln("<script type=\"text/javascript\">");
document.writeln("    /*728*90，创建于2014-4-16*/");
document.writeln("    var cpro_id = \"u1524409\";");
document.writeln("</script>");
document.writeln("<script src=\"http://cpro.baidustatic.com/cpro/ui/c.js\" type=\"text/javascript\"></script>");
document.writeln("");